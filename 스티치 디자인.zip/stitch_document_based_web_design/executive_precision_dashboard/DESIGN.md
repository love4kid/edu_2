---
name: Executive Precision Dashboard
colors:
  surface: '#fbf9fb'
  surface-dim: '#dbd9dc'
  surface-bright: '#fbf9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f5'
  surface-container: '#efedf0'
  surface-container-high: '#e9e7ea'
  surface-container-highest: '#e4e2e4'
  on-surface: '#1b1b1e'
  on-surface-variant: '#44474d'
  inverse-surface: '#303032'
  inverse-on-surface: '#f2f0f3'
  outline: '#75777e'
  outline-variant: '#c5c6ce'
  surface-tint: '#4e5f7c'
  primary: '#00030a'
  on-primary: '#ffffff'
  primary-container: '#0a1d37'
  on-primary-container: '#7586a5'
  inverse-primary: '#b6c7e9'
  secondary: '#5a5f62'
  on-secondary: '#ffffff'
  secondary-container: '#dce0e4'
  on-secondary-container: '#5e6367'
  tertiary: '#070200'
  on-tertiary: '#ffffff'
  tertiary-container: '#301700'
  on-tertiary-container: '#a67d59'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#b6c7e9'
  on-primary-fixed: '#081c36'
  on-primary-fixed-variant: '#364763'
  secondary-fixed: '#dfe3e7'
  secondary-fixed-dim: '#c3c7cb'
  on-secondary-fixed: '#171c1f'
  on-secondary-fixed-variant: '#43474b'
  tertiary-fixed: '#ffdcc0'
  tertiary-fixed-dim: '#edbd95'
  on-tertiary-fixed: '#2e1600'
  on-tertiary-fixed-variant: '#604021'
  background: '#fbf9fb'
  on-background: '#1b1b1e'
  surface-variant: '#e4e2e4'
  status-increase: '#D32F2F'
  status-decrease: '#1976D2'
  chart-pastel-1: '#A5C8ED'
  chart-pastel-2: '#B2DFDB'
  chart-pastel-3: '#FFECB3'
  chart-pastel-4: '#E1BEE7'
  chart-pastel-5: '#FFCCBC'
  dummy-data-overlay: rgba(245, 245, 245, 0.7)
  border-neutral: '#E0E0E0'
typography:
  headline-card:
    fontFamily: Noto Sans KR
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  body-main:
    fontFamily: Noto Sans KR
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  data-tabular:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: -0.02em
  chart-label:
    fontFamily: Noto Sans KR
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  news-title:
    fontFamily: Noto Sans KR
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  news-meta:
    fontFamily: Noto Sans KR
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
spacing:
  margin-page: 16px
  gutter-grid: 12px
  padding-card: 12px
  p1-height: 140px
  p2-height: auto
  p3-width: 400px
---

## Brand & Style

The design system is engineered for the high-stakes environment of corporate strategic planning. It prioritizes **information density** and **analytical speed** above all else, catering to an expert user who requires a comprehensive overview of 5 major corporations within a 30-second window.

The aesthetic follows a **Modern Corporate** movement with a focus on **Functional Minimalism**. Every UI element is stripped of decorative fluff—no shadows, no gradients, and no rounded corners—to ensure that data is the primary driver of the visual hierarchy. The style is professional, sharp, and authoritative, evoking a sense of "digital command center" rather than a consumer application.

**Key Principles:**
- **Zero-Depth Flatness:** Surfaces are distinguished by subtle tonal shifts rather than shadows.
- **Extreme Density:** Minimal padding and tight gutters maximize the 1920x1080 canvas.
- **Instant Recognition:** Information is grouped logically into three priority tiers (P1, P2, P3) to guide the eye without the need for scrolling.
- **Systematic Rigor:** Strict adherence to rectangular geometry creates a stable, trustworthy environment.

## Colors

The palette is anchored by **Professional Navy**, providing a serious business tone. This is balanced against a **Light Neutral** background to maintain legibility in high-density environments. 

**Color Usage Guidelines:**
- **Primary (Navy):** Used for headers, primary navigation cues, and high-level corporate identifiers.
- **Pastel Accents:** A 5-step pastel palette is assigned to the 5 corporations. These colors must remain consistent across the line charts and the bar charts to allow for instant cross-referencing.
- **Market Indicators:** Standard Red (#D32F2F) is strictly reserved for price increases and positive performance. Blue (#1976D2) is used for price decreases and negative performance, avoiding the "warning" connotation of yellow.
- **Dummy State:** Components requiring API integration are rendered in a desaturated, semi-transparent overlay with the label "API 연동 필요" in a muted grey.

## Typography

Typography is used as a structural tool. **Noto Sans KR** provides clarity for Korean text, while **JetBrains Mono** is utilized for all numerical data and stock tickers to ensure perfect vertical alignment (Tabular Figures).

**Typographic Rules:**
- **Numerical Integrity:** All financial figures, market caps, and price changes must use the `data-tabular` role to allow users to compare values across rows effortlessly.
- **Information Hierarchy:** Bold weights are reserved for company names and primary KPIs. Metadata (source, dates) uses the smallest legible size (11px).
- **Line Heights:** Tight line heights are employed to support the "zero-scroll" requirement.

## Layout & Spacing

The layout is a **Fixed Grid** optimized for 1920x1080. The screen is divided into a three-tier architecture that guarantees no vertical scrolling.

**Layout Zones:**
- **P1 (Top):** A horizontal strip of 5 equal-width cards. Since 5 is an odd number, they occupy a 5-column flex container spanning the full width minus page margins.
- **P2 (Bottom Left):** The primary analytical zone. It uses a vertical stack for the Line Chart (Top) and Bar Chart (Bottom). This area flexes to fill the remaining width after the P3 sidebar is accounted for.
- **P3 (Right):** A fixed-width sidebar (400px) dedicated to the news feed, allowing for a long list of headlines to be visible without disrupting the charts.

**Spacing Rhythm:** 
A strict 4px/8px/12px/16px rhythm is used. Given the density priority, the standard gutter is 12px.

## Elevation & Depth

This design system uses **Tonal Layers** rather than shadows to define hierarchy. 

- **Level 0 (Background):** Solid White (#FFFFFF) or ultra-light grey (#F8F9FA).
- **Level 1 (Cards/Containers):** Solid White with a 1px border (#E0E0E0).
- **Level 2 (Active/Hover):** A subtle fill shift to Primary Navy at 5% opacity.

The "Sharp" design language dictates that no element has a drop shadow. Depth is communicated solely through thin, high-contrast borders and functional background color changes.

## Shapes

All UI elements—including cards, buttons, input fields, and tags—must have **0px corner radius**. 

This "Sharp" geometry maximizes screen real estate and reinforces the precise, technical nature of financial data. Borders should be consistent at 1px thickness.

## Components

### P1 Status Cards
- **Structure:** Company Name (Top Left), Ticker (Top Right), Business Summary (Middle), Market Cap (Bottom).
- **Style:** 1px neutral border, no shadow. Numerical data in JetBrains Mono.
- **Dummy State:** Overlaid with a 70% opacity white mask and "API 연동 필요" centered in 12px Bold Navy text.

### P2 Charts
- **Multi-line Chart:** Use the 5 pastel colors. 1px line thickness. No area fill under lines to prevent visual clutter.
- **Bar Chart:** Grouped bars (Revenue vs Operating Profit) for each of the 5 companies. Use the same pastel color for both bars in a pair, but use a 50% hatch or lighter tint for "Operating Profit" to distinguish it from "Revenue" while maintaining company identity.
- **Period Toggle:** Rectangular segment control. Active state: Primary Navy background with white text. Inactive: White background with Navy border.

### P3 News Feed
- **List Item:** Tight vertical padding (8px). 
- **Tags:** Rectangular labels using the company's assigned pastel color as a left-border accent (4px width) to visually link the news to the company.
- **Links:** Headlines change to Primary Navy on hover with an underline.

### Status Indicators
- **Up/Down Arrows:** Small 8px triangles next to stock prices. Use `status-increase` (Red) and `status-decrease` (Blue) colors.